# Ansible Collection - psw.mail

Documentation for the collection.
